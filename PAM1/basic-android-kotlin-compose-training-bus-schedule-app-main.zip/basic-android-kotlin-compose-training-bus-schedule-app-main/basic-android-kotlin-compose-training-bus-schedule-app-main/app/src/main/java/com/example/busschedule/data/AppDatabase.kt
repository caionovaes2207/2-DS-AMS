/*
 * Copyright (C) 2023 The Android Open Source Project
 *
 * Licensed under the Apache License, Version 2.0 (the "License");
 * you may not use this file except in compliance with the License.
 * You may obtain a copy of the License at
 *
 *      https://www.apache.org/licenses/LICENSE-2.0
 *
 * Unless required by applicable law or agreed to in writing, software
 * distributed under the License is distributed on an "AS IS" BASIS,
 * WITHOUT WARRANTIES OR CONDITIONS OF ANY KIND, either express or implied.
 * See the License for the specific language governing permissions and
 * limitations under the License.
 */
package com.example.busschedule.data

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase



// Define a classe AppDatabase como o banco de dados do aplicativo.

// A entidade utilizada é BusSchedule e a versão atual do banco é 1.

@Database(entities = arrayOf(BusSchedule::class), version = 1)

abstract class AppDatabase: RoomDatabase() {

    // Método responsável por fornecer acesso às operações do banco (DAO).

    abstract fun busScheduleDao(): BusScheduleDao

    companion object {

        // Garante que apenas uma instância do banco exista durante a execução.

        @Volatile

        private var INSTANCE: AppDatabase? = null

        // Cria ou retorna a instância já existente do banco de dados.

        fun getDatabase(context: Context): AppDatabase {

            return INSTANCE ?: synchronized(this) {

                // Constrói o banco de dados utilizando a biblioteca Room.

                Room.databaseBuilder(

                    context,

                    AppDatabase::class.java,

                    "app_database"

                )

                    // Carrega um banco pré-populado que está na pasta assets.

                    .createFromAsset("database/bus_schedule.db")

                    // Caso a versão do banco mude, recria o banco automaticamente.

                    .fallbackToDestructiveMigration()

                    // Finaliza a construção do banco.

                    .build()

                    // Salva a instância criada para reutilização.

                    .also {

                        INSTANCE = it

                    }

            }

        }

    }

}
